enum State {
    FALSE, TRUE, UNDECIDED
}
enum Satisfiabil {
    SAT, UNSAT
}