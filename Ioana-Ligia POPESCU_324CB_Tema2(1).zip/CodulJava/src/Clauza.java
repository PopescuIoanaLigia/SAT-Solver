import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Clauza {
    private int nrLiterali;
    private List<Literal> literalList = new ArrayList<>();

    public Clauza(int nrLiterali, List<Literal> literalList) {
        this.nrLiterali = nrLiterali;
        this.literalList = literalList;
    }
    public int getNrLiterali() {
        return nrLiterali;
    }
    public List<Literal> getLiteralList() {
        return literalList;
    }
    public void setLiteralList(List<Literal> literalList) {
        this.literalList = literalList;
    }
}
