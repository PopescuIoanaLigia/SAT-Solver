import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class SAT {
    private int nrvariabile;
    private int nrclauze;
    private List<Clauza> listaClauze = new ArrayList<>();

    public SAT(int nrvariabile, int nrclauze, List<Clauza> listaClauze) {
        this.nrvariabile = nrvariabile;
        this.nrclauze = nrclauze;
        this.listaClauze = listaClauze;
    }

    public int getNrvariabile() {
        return nrvariabile;
    }
    public int getNrclauze() {
        return nrclauze;
    }

    public void setListaClauze(List<Clauza> listaClauze) {
        this.listaClauze = listaClauze;
    }
}
