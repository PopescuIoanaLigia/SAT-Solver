import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Solver {
    SAT problemaSat = null;
    public static void main(String[] args) {
        // Verific nr fisiere specificate in apelare = 2
        if (args.length != 2) {
            System.err.println("Usage: java Solver <input_file> <output_file>");
            System.exit(1);
        }

        String inputFile = args[0];
        String outputFile = args[1];
        SAT sat  = null;

        try { //citirea din fisier si initializarea obiectului SAT
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            String firstLine = reader.readLine();
            String[] tokens = firstLine.split(" ");
            if(tokens[0] != "p" || tokens[1] != "cnf")
            {
                throw new ExceptieStartLineKey("p cnf");
            }

            // salvam numarul de variabile si clauze
            int nrvariabile = Integer.parseInt(tokens[2]);
            int nrclauze = Integer.parseInt(tokens[3]);

            List<Clauza> listaClauze = new ArrayList<Clauza>();

            for(int i=0; i < nrclauze; i++){
                String primaClauza = reader.readLine();
                String[] variabile = primaClauza.split(" ");
                int j = 0;
                List<Literal> literals = new ArrayList<Literal>();
                int nrVariabile = 0;
                while(!variabile[j].equals("0")){
                    nrVariabile++;

                    // salvez literalul drept int
                    int variabila = Integer.parseInt(variabile[j]);
                    boolean valoare;
                    if( variabila < 0){
                        valoare = false;
                    } else {
                        valoare = true;
                    }
                    // salvez numarul valorii fara minus
                    int nrVariabila = Math.abs(variabila);

                    Literal literal = new Literal(nrVariabila, valoare);
                    literals.add(literal);
                }
                Clauza clauza = new Clauza(nrvariabile, literals);
                listaClauze.add(clauza);
                reader.close();
            }
            sat = new SAT(nrvariabile, nrclauze, listaClauze);
        }
        catch (FileNotFoundException e) {
            System.err.println("Fisierul nu a fost gasit: " + inputFile);
        }
        catch (IOException e) {
            System.err.println("Fisierul nu a io: " + inputFile);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }

        // apeleaza functia aici

        try {
            FileWriter writer = new FileWriter(outputFile);
            writer.write("test");
            writer.close();
            System.out.println("Textul a fost scris în fișier.");
        } catch (IOException e) {
            System.out.println("Eroare la scrierea fișierului: " + e.getMessage());
        }

        System.out.println(sat);
    }
}
